package sistema.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class ConsoleUtil {
    private static final Scanner scanner = new Scanner(System.in);

    public static String readLine(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    public static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = scanner.nextLine().trim();
            try { return Integer.parseInt(s); } catch (NumberFormatException ex) { System.out.println("Número inválido. Tente novamente."); }
        }
    }

    public static LocalDateTime readDateTime(String prompt) {
        while (true) {
            System.out.print(prompt);
            String s = scanner.nextLine().trim();
            try { return LocalDateTime.parse(s); }
            catch (DateTimeParseException ex) { System.out.println("Formato inválido. Use AAAA-MM-DDThh:mm (ex: 2025-09-12T20:00)"); }
        }
    }

    public static void clearScreen() {
        for (int i = 0; i < 30; i++) System.out.println();
    }
}