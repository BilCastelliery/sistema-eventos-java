package sistema;

import sistema.manager.EventManager;
import sistema.utils.ConsoleUtil;
import sistema.models.User;

public class Main {
    public static void main(String[] args) {
        EventManager manager = new EventManager();
        manager.loadEvents();

        ConsoleUtil.clearScreen();
        System.out.println("=== Sistema de Eventos - Console ===\n");

        User currentUser = null;
        while (true) {
            if (currentUser == null) {
                System.out.println("1) Cadastrar usuário");
                System.out.println("2) Entrar como usuário existente (usar ID)");
                System.out.println("3) Continuar como visitante (sem salvar usuário)");
                System.out.println("0) Sair");
                int opt = ConsoleUtil.readInt("Escolha uma opção: ");
                switch (opt) {
                    case 1:
                        currentUser = manager.registerUser();
                        break;
                    case 2:
                        currentUser = manager.loginAsUser();
                        break;
                    case 3:
                        currentUser = manager.createGuestUser();
                        break;
                    case 0:
                        manager.saveEvents();
                        System.out.println("Saindo... até mais!");
                        return;
                    default:
                        System.out.println("Opção inválida!");
                }
            } else {
                manager.mainMenuForUser(currentUser);
                if (!manager.isUserLogged(currentUser)) {
                    currentUser = null;
                }
            }
        }
    }
}
