package sistema.manager;

import sistema.models.Event;
import sistema.models.EventCategory;
import sistema.models.User;
import sistema.storage.Storage;
import sistema.utils.ConsoleUtil;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class EventManager {
    private final List<Event> events = new ArrayList<>();
    private final Map<Integer, User> users = new HashMap<>();
    private final Storage storage = new Storage("events.data");
    private int nextEventId = 1;
    private int nextUserId = 1;

    public void loadEvents() {
        List<Event> loaded = storage.loadEvents();
        events.clear();
        events.addAll(loaded);
        nextEventId = events.stream().mapToInt(Event::getId).max().orElse(0) + 1;
        System.out.println(events.size() + " eventos carregados de events.data\n");
    }

    public void saveEvents() {
        storage.saveEvents(events);
        System.out.println("Eventos salvos em events.data\n");
    }

    public User registerUser() {
        System.out.println("--- Cadastro de usuário ---");
        String name = ConsoleUtil.readLine("Nome completo: ");
        String email = ConsoleUtil.readLine("Email: ");
        String city = ConsoleUtil.readLine("Cidade (local dos eventos): ");
        String phone = ConsoleUtil.readLine("Telefone (opcional): ");
        User u = new User(nextUserId++, name, email, city, phone);
        users.put(u.getId(), u);
        System.out.println("Usuário cadastrado com ID: " + u.getId());
        return u;
    }

    public User loginAsUser() {
        int id = ConsoleUtil.readInt("Digite o ID do usuário: ");
        User u = users.get(id);
        if (u == null) {
            System.out.println("Usuário não encontrado. Deseja cadastrar? (s/n)");
            String r = ConsoleUtil.readLine("");
            if (r.equalsIgnoreCase("s")) return registerUser();
            return null;
        }
        System.out.println("Bem vindo, " + u.getName());
        return u;
    }

    public User createGuestUser() {
        User u = new User(0, "Visitante", "", "", "");
        System.out.println("Continuando como visitante (ID=0)");
        return u;
    }

    public boolean isUserLogged(User u) {
        return u != null && (u.getId() == 0 || users.containsKey(u.getId()));
    }

    public void mainMenuForUser(User user) {
        while (true) {
            System.out.println("\n--- Menu (Usuário: " + user.getName() + ") ---");
            System.out.println("1) Criar evento");
            System.out.println("2) Listar todos os eventos");
            System.out.println("3) Ver eventos por categoria");
            System.out.println("4) Ver meus eventos confirmados");
            System.out.println("5) Procurar eventos próximos / em andamento / passados");
            System.out.println("6) Participar de evento");
            System.out.println("7) Cancelar participação");
            System.out.println("8) Salvar eventos");
            System.out.println("9) Logout");
            System.out.println("0) Sair do programa");
            int opt = ConsoleUtil.readInt("Escolha: ");
            switch (opt) {
                case 1: createEvent(user); break;
                case 2: listEvents(); break;
                case 3: listByCategory(); break;
                case 4: listUserParticipations(user); break;
                case 5: showTimeFiltered(); break;
                case 6: participate(user); break;
                case 7: cancelParticipation(user); break;
                case 8: saveEvents(); break;
                case 9: System.out.println("Logout realizado."); return;
                case 0: saveEvents(); System.out.println("Saindo... Até logo!"); System.exit(0);
                default: System.out.println("Opção inválida.");
            }
        }
    }

    private void createEvent(User creator) {
        System.out.println("--- Criar Evento ---");
        String name = ConsoleUtil.readLine("Nome do evento: ");
        String address = ConsoleUtil.readLine("Endereço: ");
        for (EventCategory c : EventCategory.values()) System.out.println(c.ordinal() + ") " + c);
        int catIndex = ConsoleUtil.readInt("Escolha a categoria (número): ");
        EventCategory category = EventCategory.values()[Math.max(0, Math.min(catIndex, EventCategory.values().length - 1))];
        LocalDateTime dt = ConsoleUtil.readDateTime("Data e hora (AAAA-MM-DDThh:mm, ex: 2025-09-12T20:00): ");
        String desc = ConsoleUtil.readLine("Descrição: ");
        Event e = new Event(nextEventId++, name, address, category, dt, desc);
        events.add(e);
        System.out.println("Evento criado com ID: " + e.getId());
    }

    public void listEvents() {
        System.out.println("--- Lista de Eventos (ordenados por horário) ---");
        List<Event> sorted = events.stream().sorted(Comparator.comparing(Event::getDateTime)).collect(Collectors.toList());
        if (sorted.isEmpty()) {
            System.out.println("Nenhum evento cadastrado.");
            return;
        }
        sorted.forEach(e -> System.out.println(e.briefInfo()));
    }

    private void listByCategory() {
        for (EventCategory c : EventCategory.values()) System.out.println(c.ordinal() + ") " + c);
        int idx = ConsoleUtil.readInt("Categoria: ");
        if (idx < 0 || idx >= EventCategory.values().length) {
            System.out.println("Categoria inválida.");
            return;
        }
        EventCategory cat = EventCategory.values()[idx];
        events.stream().filter(e -> e.getCategory() == cat).sorted(Comparator.comparing(Event::getDateTime)).forEach(e -> System.out.println(e.briefInfo()));
    }

    private void listUserParticipations(User user) {
        System.out.println("--- Meus eventos confirmados ---");
        events.stream().filter(e -> e.getParticipants().contains(user.getId())).sorted(Comparator.comparing(Event::getDateTime)).forEach(e -> System.out.println(e.briefInfo()));
    }

    private void showTimeFiltered() {
        LocalDateTime now = LocalDateTime.now();
        System.out.println("Agora: " + now.toString());
        System.out.println("Eventos em andamento:");
        events.stream().filter(e -> e.isOngoing(now)).forEach(e -> System.out.println(e.detailedInfoWithStatus(now)));
        System.out.println("\nEventos próximos (futuros):");
        events.stream().filter(e -> e.getDateTime().isAfter(now)).sorted(Comparator.comparing(Event::getDateTime)).forEach(e -> System.out.println(e.detailedInfoWithStatus(now)));
        System.out.println("\nEventos já ocorridos:");
        events.stream().filter(e -> e.getDateTime().isBefore(now) && !e.isOngoing(now)).sorted(Comparator.comparing(Event::getDateTime).reversed()).forEach(e -> System.out.println(e.detailedInfoWithStatus(now)));
    }

    private void participate(User user) {
        int id = ConsoleUtil.readInt("Digite o ID do evento que deseja participar: ");
        Optional<Event> opt = events.stream().filter(e -> e.getId() == id).findFirst();
        if (!opt.isPresent()) { System.out.println("Evento não encontrado."); return; }
        Event e = opt.get();
        if (e.getParticipants().contains(user.getId())) {
            System.out.println("Você já confirmou presença nesse evento.");
            return;
        }
        e.getParticipants().add(user.getId());
        System.out.println("Presença confirmada para o evento: " + e.getName());
    }

    private void cancelParticipation(User user) {
        int id = ConsoleUtil.readInt("Digite o ID do evento que deseja cancelar participação: ");
        Optional<Event> opt = events.stream().filter(e -> e.getId() == id).findFirst();
        if (!opt.isPresent()) { System.out.println("Evento não encontrado."); return; }
        Event e = opt.get();
        if (!e.getParticipants().contains(user.getId())) {
            System.out.println("Você não está inscrito nesse evento.");
            return;
        }
        e.getParticipants().remove((Integer) user.getId());
        System.out.println("Participação cancelada para o evento: " + e.getName());
    }
}
