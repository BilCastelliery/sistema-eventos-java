package sistema.models;

public enum EventCategory {
    FESTA,
    ESPORTES,
    SHOW,
    CULTURA,
    CONFERENCIA,
    OUTROS
}