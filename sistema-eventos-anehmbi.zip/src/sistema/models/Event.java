package sistema.models;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Event {
    private final int id;
    private String name;
    private String address;
    private EventCategory category;
    private LocalDateTime dateTime;
    private String description;
    private final List<Integer> participants = new ArrayList<>();

    public static final int DEFAULT_DURATION_MIN = 180;

    public Event(int id, String name, String address, EventCategory category, LocalDateTime dateTime, String description) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.category = category;
        this.dateTime = dateTime;
        this.description = description;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public EventCategory getCategory() { return category; }
    public LocalDateTime getDateTime() { return dateTime; }
    public String getDescription() { return description; }
    public List<Integer> getParticipants() { return participants; }

    public boolean isOngoing(LocalDateTime now) {
        LocalDateTime end = dateTime.plusMinutes(DEFAULT_DURATION_MIN);
        return (now.isEqual(dateTime) || now.isAfter(dateTime)) && now.isBefore(end);
    }

    public String briefInfo() {
        return String.format("ID:%d | %s | %s | %s | %s | participantes:%d", id, name, address, category, dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME), participants.size());
    }

    public String detailedInfoWithStatus(LocalDateTime now) {
        String status;
        if (isOngoing(now)) status = "EM ANDAMENTO";
        else if (dateTime.isAfter(now)) {
            long minutes = Duration.between(now, dateTime).toMinutes();
            status = "FALTA " + minutes + " minutos";
        } else status = "JÁ OCORREU";
        return String.format("ID:%d | %s | %s | %s | %s | %s | participantes:%d", id, name, address, category, dateTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME), status, participants.size());
    }
}