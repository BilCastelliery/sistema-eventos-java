package sistema.storage;

import sistema.models.Event;
import sistema.models.EventCategory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Storage {
    private final Path path;

    public Storage(String filename) {
        this.path = Path.of(filename);
    }

    public List<Event> loadEvents() {
        List<Event> list = new ArrayList<>();
        try {
            if (!Files.exists(path)) {
                Files.createFile(path);
                return list;
            }
            List<String> lines = Files.readAllLines(path);
            for (String line : lines) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split("\\|");
                if (parts.length < 6) continue;
                int id = Integer.parseInt(parts[0]);
                String nome = parts[1];
                String endereco = parts[2];
                EventCategory cat = EventCategory.valueOf(parts[3]);
                LocalDateTime dt = LocalDateTime.parse(parts[4]);
                String desc = parts[5];
                Event e = new Event(id, nome, endereco, cat, dt, desc);
                if (parts.length >= 7 && !parts[6].isEmpty()) {
                    List<Integer> partIds = Arrays.stream(parts[6].split(",")).map(String::trim).filter(s -> !s.isEmpty()).map(Integer::parseInt).collect(Collectors.toList());
                    e.getParticipants().addAll(partIds);
                }
                list.add(e);
            }
        } catch (IOException ex) {
            System.err.println("Erro ao ler events.data: " + ex.getMessage());
        }
        return list;
    }

    public void saveEvents(List<Event> events) {
        try (BufferedWriter bw = Files.newBufferedWriter(path)) {
            for (Event e : events) {
                String participants = e.getParticipants().stream().map(Object::toString).collect(Collectors.joining(","));
                String line = String.join("|", String.valueOf(e.getId()), e.getName(), e.getAddress(), e.getCategory().name(), e.getDateTime().toString(), e.getDescription(), participants);
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.err.println("Erro ao salvar events.data: " + ex.getMessage());
        }
    }
}